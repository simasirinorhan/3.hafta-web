require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

const makeAdmin = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        const email = process.argv[2];

        if (!email) {
            console.log('Kullanım: node make-admin.js <email>');
            process.exit(1);
        }

        const user = await User.findOne({ email });
        if (!user) {
            console.log('Kullanıcı bulunamadı!');
            process.exit(1);
        }

        user.role = 'admin';
        await user.save();
        console.log(`${user.email} başarıyla admin yapıldı!`);
        process.exit(0);
    } catch (error) {
        console.error('Hata:', error);
        process.exit(1);
    }
};

makeAdmin();
