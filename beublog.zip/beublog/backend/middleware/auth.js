const jwt = require('jsonwebtoken');
const User = require('../models/User');

const protect = async (req, res, next) => {
    let token;

    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        try {
            token = req.headers.authorization.split(' ')[1];
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            req.user = await User.findById(decoded.id).select('-password');
            if (!req.user) {
                return res.status(401).json({ message: 'Yetkisiz erişim, kullanıcı bulunamadı' });
            }
            next();
        } catch (error) {
            console.error(error);
            return res.status(401).json({ message: 'Yetkisiz erişim, token geçersiz' });
        }
    }

    if (!token) {
        return res.status(401).json({ message: 'Yetkisiz erişim, token yok' });
    }
};

const admin = (req, res, next) => {
    if (req.user && req.user.role === 'admin') {
        next();
    } else {
        res.status(403).json({ message: 'Sadece admin yetkisi ile erişilebilir' });
    }
};

module.exports = { protect, admin };
