const express = require('express');
const Category = require('../models/Category');
const { protect, admin } = require('../middleware/auth');
const router = express.Router();
const slugify = require('slugify');

// @route GET /api/categories
router.get('/', async (req, res) => {
    try {
        const categories = await Category.find().sort({ createdAt: -1 });
        res.json(categories);
    } catch (error) {
        res.status(500).json({ message: 'Sunucu hatası', error: error.message });
    }
});

// @route POST /api/categories
router.post('/', protect, admin, async (req, res) => {
    try {
        const { name } = req.body;
        if (!name) return res.status(400).json({ message: 'Kategori adı gerekli' });

        const slug = slugify(name, { lower: true, strict: true, locale: 'tr' });
        const existing = await Category.findOne({ slug });
        if (existing) return res.status(400).json({ message: 'Bu kategori zaten var' });

        const category = await Category.create({ name, slug });
        res.status(201).json(category);
    } catch (error) {
        res.status(500).json({ message: 'Sunucu hatası', error: error.message });
    }
});

// @route DELETE /api/categories/:id
router.delete('/:id', protect, admin, async (req, res) => {
    try {
        const category = await Category.findById(req.params.id);
        if (!category) return res.status(404).json({ message: 'Kategori bulunamadı' });

        await category.deleteOne();
        res.json({ message: 'Kategori silindi' });
    } catch (error) {
        res.status(500).json({ message: 'Sunucu hatası', error: error.message });
    }
});

module.exports = router;
