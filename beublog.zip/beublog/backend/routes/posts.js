const express = require('express');
const slugify = require('slugify');
const Post = require('../models/Post');
const { protect, admin } = require('../middleware/auth');
const router = express.Router();

// @route GET /api/posts
router.get('/', async (req, res) => {
    try {
        const posts = await Post.find({ status: 'published' })
            .populate('author', 'username profilePicture')
            .populate('category', 'name slug')
            .sort({ createdAt: -1 });
        res.json(posts);
    } catch (error) {
        res.status(500).json({ message: 'Sunucu hatası', error: error.message });
    }
});

// @route GET /api/posts/by-slug/:slug
router.get('/by-slug/:slug', async (req, res) => {
    try {
        const post = await Post.findOne({ slug: req.params.slug })
            .populate('author', 'username profilePicture bio')
            .populate('category', 'name slug');

        if (!post) {
            return res.status(404).json({ message: 'Yazı bulunamadı' });
        }
        res.json(post);
    } catch (error) {
        res.status(500).json({ message: 'Sunucu hatası', error: error.message });
    }
});

// @route POST /api/posts
router.post('/', protect, async (req, res) => {
    try {
        const { title, content, image, category } = req.body;

        if (!title || !content) {
            return res.status(400).json({ message: 'Başlık ve içerik zorunludur' });
        }

        let slug = slugify(title, { lower: true, strict: true, locale: 'tr' });

        // Ensure slug is unique
        let existingPost = await Post.findOne({ slug });
        if (existingPost) {
            slug = `${slug}-${Date.now()}`;
        }

        const post = await Post.create({
            title,
            slug,
            content,
            image,
            category: category || null,
            author: req.user._id
        });

        res.status(201).json(post);
    } catch (error) {
        res.status(500).json({ message: 'Sunucu hatası', error: error.message });
    }
});

// @route PUT /api/posts/:id
router.put('/:id', protect, async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);

        if (!post) {
            return res.status(404).json({ message: 'Yazı bulunamadı' });
        }

        // Check ownership or admin
        if (post.author.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Yetkisiz erişim' });
        }

        post.title = req.body.title || post.title;
        post.content = req.body.content || post.content;
        post.image = req.body.image !== undefined ? req.body.image : post.image;
        post.category = req.body.category || post.category;

        if (req.body.title) {
            post.slug = slugify(req.body.title, { lower: true, strict: true, locale: 'tr' });
        }

        const updatedPost = await post.save();
        res.json(updatedPost);
    } catch (error) {
        res.status(500).json({ message: 'Sunucu hatası', error: error.message });
    }
});

// @route DELETE /api/posts/:id
router.delete('/:id', protect, async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);

        if (!post) {
            return res.status(404).json({ message: 'Yazı bulunamadı' });
        }

        if (post.author.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Yetkisiz erişim' });
        }

        await post.deleteOne();
        res.json({ message: 'Yazı silindi' });
    } catch (error) {
        res.status(500).json({ message: 'Sunucu hatası', error: error.message });
    }
});

// @route PUT /api/posts/:id/like
router.put('/:id/like', protect, async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);

        if (!post) {
            return res.status(404).json({ message: 'Yazı bulunamadı' });
        }

        const isLiked = post.likes.includes(req.user._id);

        if (isLiked) {
            // Unlike
            post.likes = post.likes.filter(id => id.toString() !== req.user._id.toString());
        } else {
            // Like
            post.likes.push(req.user._id);
        }

        await post.save();
        res.json(post.likes);
    } catch (error) {
        res.status(500).json({ message: 'Sunucu hatası', error: error.message });
    }
});

// @route PUT /api/posts/:id/status
router.put('/:id/status', protect, admin, async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);

        if (!post) {
            return res.status(404).json({ message: 'Yazı bulunamadı' });
        }

        post.status = req.body.status || post.status;
        const updatedPost = await post.save();
        res.json(updatedPost);
    } catch (error) {
        res.status(500).json({ message: 'Sunucu hatası', error: error.message });
    }
});

module.exports = router;
