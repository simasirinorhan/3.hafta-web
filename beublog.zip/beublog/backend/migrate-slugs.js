require('dotenv').config();
const mongoose = require('mongoose');
const slugify = require('slugify');
const Post = require('./models/Post');
const Category = require('./models/Category');

const migrateSlugs = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('Veritabanına bağlanıldı.');

        // Migrate Posts
        const posts = await Post.find({ slug: { $exists: false } });
        console.log(`${posts.length} adet yazıda slug eksik. Güncelleniyor...`);
        for (let post of posts) {
            post.slug = slugify(post.title, { lower: true, strict: true, locale: 'tr' });
            let existingPost = await Post.findOne({ slug: post.slug });
            if (existingPost && existingPost._id.toString() !== post._id.toString()) {
                post.slug = `${post.slug}-${Date.now()}`;
            }
            await post.save();
        }

        // Migrate Categories
        const categories = await Category.find({ slug: { $exists: false } });
        console.log(`${categories.length} adet kategoride slug eksik. Güncelleniyor...`);
        for (let category of categories) {
            category.slug = slugify(category.name, { lower: true, strict: true, locale: 'tr' });
            await category.save();
        }

        console.log('Migrasyon tamamlandı!');
        process.exit(0);
    } catch (error) {
        console.error('Hata:', error);
        process.exit(1);
    }
};

migrateSlugs();
