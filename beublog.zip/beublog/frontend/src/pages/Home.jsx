import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../api';
import './Home.css';

const Home = () => {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchPosts = async () => {
            try {
                const res = await api.get('/posts');
                setPosts(res.data);
            } catch (error) {
                console.error('Yazılar yüklenirken hata:', error);
            } finally {
                setLoading(false);
            }
        };
        fetchPosts();
    }, []);

    if (loading) return <div className="loading">Yükleniyor...</div>;

    return (
        <div className="home-page">
            <div className="hero">
                <h1 className="hero-title">En Yeni Yazılar</h1>
                <p className="hero-subtitle">Teknoloji, yazılım ve tasarım dünyasından güncel makaleler.</p>
            </div>

            <div className="posts-grid">
                {posts.length === 0 ? (
                    <p>Henüz yazı bulunmuyor.</p>
                ) : (
                    posts.map(post => (
                        <div key={post._id} className="post-card surface">
                            {post.image && (
                                <div className="post-image-container">
                                    <img src={`${import.meta.env.VITE_BACKEND_URL || 'http://localhost:5000'}${post.image}`} alt={post.title} className="post-image" />
                                </div>
                            )}
                            <div className="post-content">
                                {post.category && <span className="post-category">{post.category.name}</span>}
                                <Link to={`/post/${post.slug}`} className="post-title-link">
                                    <h3 className="post-title">{post.title}</h3>
                                </Link>
                                <div className="post-meta">
                                    <span className="post-author">{post.author?.username || 'Anonim'}</span>
                                    <span className="post-date">{new Date(post.createdAt).toLocaleDateString('tr-TR')}</span>
                                </div>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export default Home;
