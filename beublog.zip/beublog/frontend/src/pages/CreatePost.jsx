import { useState, useContext, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { AuthContext } from '../context/AuthContext';
import api from '../api';
import './PostForm.css';

const CreatePost = () => {
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [category, setCategory] = useState('');
    const [categories, setCategories] = useState([]);
    const [image, setImage] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const fileInputRef = useRef(null);

    useEffect(() => {
        if (!user) {
            navigate('/login');
        }
        const fetchCategories = async () => {
            try {
                const res = await api.get('/categories');
                setCategories(res.data);
            } catch (err) {
                console.error(err);
            }
        };
        fetchCategories();
    }, [user, navigate]);

    const handleImageUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('image', file);

        try {
            const res = await api.post('/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            setImage(res.data.imageUrl);
        } catch (err) {
            setError('Görsel yüklenemedi.');
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);

        try {
            const { data } = await api.post('/posts', {
                title,
                content,
                category: category || null,
                image
            });
            navigate(`/post/${data.slug}`);
        } catch (err) {
            setError(err.response?.data?.message || 'Yazı oluşturulamadı.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="post-form-container surface">
            <h2>Yeni Yazı Oluştur</h2>
            {error && <div className="error-alert">{error}</div>}

            <form onSubmit={handleSubmit} className="post-form">
                <div className="form-group">
                    <label>Başlık</label>
                    <input
                        type="text"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        required
                        placeholder="Yazınızın başlığı..."
                    />
                </div>

                <div className="form-group">
                    <label>Kategori</label>
                    <select value={category} onChange={(e) => setCategory(e.target.value)}>
                        <option value="">Kategori Seçin (Opsiyonel)</option>
                        {categories.map(c => (
                            <option key={c._id} value={c._id}>{c.name}</option>
                        ))}
                    </select>
                </div>

                <div className="form-group">
                    <label>Kapak Görseli (Opsiyonel)</label>
                    <div className="image-upload-wrapper">
                        <input
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            ref={fileInputRef}
                            style={{ display: 'none' }}
                        />
                        <button
                            type="button"
                            className="btn-outline"
                            onClick={() => fileInputRef.current.click()}
                        >
                            Görsel Seç
                        </button>
                        {image && (
                            <div className="image-preview">
                                <img src={`${import.meta.env.VITE_BACKEND_URL || 'http://localhost:5000'}${image}`} alt="Preview" />
                                <button type="button" className="remove-img-btn" onClick={() => setImage('')}>Kaldır</button>
                            </div>
                        )}
                    </div>
                </div>

                <div className="form-group">
                    <label>İçerik</label>
                    <div className="quill-wrapper">
                        <ReactQuill
                            theme="snow"
                            value={content}
                            onChange={setContent}
                            className="editor"
                            placeholder="Hikayenizi anlatın..."
                        />
                    </div>
                </div>

                <button type="submit" className="btn-primary submit-btn" disabled={loading}>
                    {loading ? 'Yayınlanıyor...' : 'Yayınla'}
                </button>
            </form>
        </div>
    );
};

export default CreatePost;
