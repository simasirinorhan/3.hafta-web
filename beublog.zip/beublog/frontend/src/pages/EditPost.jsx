import { useState, useContext, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { AuthContext } from '../context/AuthContext';
import api from '../api';
import './PostForm.css';

const EditPost = () => {
    const { user } = useContext(AuthContext);
    const { id } = useParams();
    const navigate = useNavigate();

    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [category, setCategory] = useState('');
    const [categories, setCategories] = useState([]);
    const [image, setImage] = useState('');

    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState('');
    const fileInputRef = useRef(null);

    useEffect(() => {
        if (!user) {
            navigate('/login');
            return;
        }

        const fetchData = async () => {
            try {
                const catRes = await api.get('/categories');
                setCategories(catRes.data);

                const postRes = await api.get('/auth/me/posts');
                const post = postRes.data.find(p => p._id === id);

                if (!post) {
                    setError('Yazı bulunamadı veya yetkiniz yok.');
                    setLoading(false);
                    return;
                }

                setTitle(post.title);
                setContent(post.content);
                setCategory(post.category ? post.category._id : '');
                setImage(post.image || '');
            } catch (err) {
                console.error(err);
                setError('Veriler yüklenemedi.');
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, [user, navigate, id]);

    const handleImageUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('image', file);

        try {
            const res = await api.post('/upload', formData, {
                headers: { 'Content-Type': 'multipart/form-data' },
            });
            setImage(res.data.imageUrl);
        } catch (err) {
            setError('Görsel yüklenemedi.');
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setSaving(true);

        try {
            await api.put(`/posts/${id}`, {
                title,
                content,
                category: category || null,
                image
            });
            navigate(`/dashboard`);
        } catch (err) {
            setError(err.response?.data?.message || 'Yazı güncellenemedi.');
        } finally {
            setSaving(false);
        }
    };

    if (loading) return <div className="loading">Yükleniyor...</div>;

    return (
        <div className="post-form-container surface">
            <h2>Yazıyı Düzenle</h2>
            {error && <div className="error-alert">{error}</div>}

            {!error && (
                <form onSubmit={handleSubmit} className="post-form">
                    <div className="form-group">
                        <label>Başlık</label>
                        <input
                            type="text"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label>Kategori</label>
                        <select value={category} onChange={(e) => setCategory(e.target.value)}>
                            <option value="">Kategori Seçin (Opsiyonel)</option>
                            {categories.map(c => (
                                <option key={c._id} value={c._id}>{c.name}</option>
                            ))}
                        </select>
                    </div>

                    <div className="form-group">
                        <label>Kapak Görseli</label>
                        <div className="image-upload-wrapper">
                            <input
                                type="file"
                                accept="image/*"
                                onChange={handleImageUpload}
                                ref={fileInputRef}
                                style={{ display: 'none' }}
                            />
                            <button
                                type="button"
                                className="btn-outline"
                                onClick={() => fileInputRef.current.click()}
                            >
                                Değiştir
                            </button>
                            {image && (
                                <div className="image-preview">
                                    <img src={`${import.meta.env.VITE_BACKEND_URL || 'http://localhost:5000'}${image}`} alt="Preview" />
                                    <button type="button" className="remove-img-btn" onClick={() => setImage('')}>Kaldır</button>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="form-group">
                        <label>İçerik</label>
                        <div className="quill-wrapper">
                            <ReactQuill
                                theme="snow"
                                value={content}
                                onChange={setContent}
                                className="editor"
                            />
                        </div>
                    </div>

                    <button type="submit" className="btn-primary submit-btn" disabled={saving}>
                        {saving ? 'Kaydediliyor...' : 'Değişiklikleri Kaydet'}
                    </button>
                </form>
            )}
        </div>
    );
};

export default EditPost;
