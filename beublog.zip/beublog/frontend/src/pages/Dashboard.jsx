import { useState, useEffect, useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import api from '../api';
import './Dashboard.css';
import { Edit, Trash2 } from 'lucide-react';

const Dashboard = () => {
    const { user, setUser } = useContext(AuthContext);
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);

    const [isEditingProfile, setIsEditingProfile] = useState(false);
    const [bio, setBio] = useState(user?.bio || '');

    useEffect(() => {
        const fetchUserPosts = async () => {
            try {
                const res = await api.get('/auth/me/posts');
                setPosts(res.data);
            } catch (error) {
                console.error('Yazılar yüklenirken hata:', error);
            } finally {
                setLoading(false);
            }
        };
        if (user) {
            fetchUserPosts();
            setBio(user.bio || '');
        }
    }, [user]);

    const handleDelete = async (id) => {
        if (window.confirm('Bu yazıyı silmek istediğinize emin misiniz?')) {
            try {
                await api.delete(`/posts/${id}`);
                setPosts(posts.filter(p => p._id !== id));
            } catch (error) {
                console.error('Silme hatası:', error);
                alert('Yazı silinemedi.');
            }
        }
    };

    const handleProfileUpdate = async (e) => {
        e.preventDefault();
        try {
            const res = await api.put('/auth/me/profile', { bio });
            setUser(res.data);
            localStorage.setItem('user', JSON.stringify(res.data));
            setIsEditingProfile(false);
        } catch (error) {
            console.error(error);
            alert('Profil güncellenemedi.');
        }
    };

    if (!user) return <div className="container">Lütfen giriş yapın.</div>;
    if (loading) return <div className="loading">Yükleniyor...</div>;

    return (
        <div className="dashboard-page">
            <div className="dashboard-header surface">
                <div className="profile-info">
                    {user.profilePicture ? (
                        <img src={`${import.meta.env.VITE_BACKEND_URL || 'http://localhost:5000'}${user.profilePicture}`} alt="Profil" className="profile-img" />
                    ) : (
                        <div className="profile-img-placeholder">{user.username.charAt(0).toUpperCase()}</div>
                    )}

                    <div className="profile-details">
                        <h2>{user.username}</h2>
                        <p className="user-email">{user.email}</p>
                        <span className={`user-role ${user.role}`}>{user.role === 'admin' ? 'Yönetici' : 'Yazar'}</span>
                    </div>
                </div>

                <div className="profile-actions">
                    {isEditingProfile ? (
                        <form onSubmit={handleProfileUpdate} className="profile-form">
                            <textarea
                                value={bio}
                                onChange={(e) => setBio(e.target.value)}
                                placeholder="Kendinizden bahsedin..."
                                className="bio-input"
                            />
                            <div className="form-actions">
                                <button type="button" onClick={() => setIsEditingProfile(false)} className="btn-outline">İptal</button>
                                <button type="submit" className="btn-primary">Kaydet</button>
                            </div>
                        </form>
                    ) : (
                        <div className="bio-display">
                            <p>{user.bio || 'Henüz bir biyografi eklemediniz.'}</p>
                            <button onClick={() => setIsEditingProfile(true)} className="btn-outline btn-sm">Profili Düzenle</button>
                        </div>
                    )}
                </div>
            </div>

            <div className="dashboard-content">
                <div className="dashboard-section-header">
                    <h3>Yazılarım ({posts.length})</h3>
                    <Link to="/create-post" className="btn-primary">Yeni Yazı</Link>
                </div>

                <div className="dashboard-posts">
                    {posts.length === 0 ? (
                        <p className="no-data">Henüz hiç yazı yazmadınız.</p>
                    ) : (
                        <div className="table-responsive surface">
                            <table className="posts-table">
                                <thead>
                                    <tr>
                                        <th>Başlık</th>
                                        <th>Durum</th>
                                        <th>Tarih</th>
                                        <th>İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {posts.map(post => (
                                        <tr key={post._id}>
                                            <td>
                                                <Link to={`/post/${post.slug}`} className="table-link">{post.title}</Link>
                                            </td>
                                            <td>
                                                <span className={`status-badge ${post.status}`}>
                                                    {post.status === 'published' ? 'Yayında' : 'Askıda'}
                                                </span>
                                            </td>
                                            <td>{new Date(post.createdAt).toLocaleDateString('tr-TR')}</td>
                                            <td>
                                                <div className="table-actions">
                                                    <Link to={`/edit-post/${post._id}`} className="action-btn edit" title="Düzenle">
                                                        <Edit size={18} />
                                                    </Link>
                                                    <button onClick={() => handleDelete(post._id)} className="action-btn delete" title="Sil">
                                                        <Trash2 size={18} />
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
