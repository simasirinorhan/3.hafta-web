import { useState, useEffect, useContext } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../api';
import { AuthContext } from '../context/AuthContext';
import { Heart } from 'lucide-react';
import './PostDetail.css';

const PostDetail = () => {
    const { slug } = useParams();
    const { user } = useContext(AuthContext);
    const [post, setPost] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchPost = async () => {
            try {
                const res = await api.get(`/posts/by-slug/${slug}`);
                setPost(res.data);
            } catch (err) {
                setError('Yazı bulunamadı.');
            } finally {
                setLoading(false);
            }
        };
        fetchPost();
    }, [slug]);

    const handleLike = async () => {
        if (!user) {
            alert('Beğenmek için giriş yapmalısınız.');
            return;
        }
        try {
            const res = await api.put(`/posts/${post._id}/like`);
            setPost({ ...post, likes: res.data });
        } catch (err) {
            console.error(err);
        }
    };

    if (loading) return <div className="loading">Yükleniyor...</div>;
    if (error || !post) return <div className="container error-text">{error}</div>;

    const isLiked = user && post.likes?.includes(user._id);

    return (
        <article className="post-detail-container surface">
            <div className="post-header">
                {post.category && <span className="post-category-tag">{post.category.name}</span>}
                <h1 className="post-detail-title">{post.title}</h1>

                <div className="post-meta-info">
                    <div className="author-info">
                        {post.author.profilePicture ? (
                            <img src={`${import.meta.env.VITE_BACKEND_URL || 'http://localhost:5000'}${post.author.profilePicture}`} alt={post.author.username} className="author-avatar" />
                        ) : (
                            <div className="author-avatar-placeholder">{post.author.username.charAt(0).toUpperCase()}</div>
                        )}
                        <div>
                            <p className="author-name">{post.author.username}</p>
                            <p className="post-date">{new Date(post.createdAt).toLocaleDateString('tr-TR')} · Okuma Süresi: {Math.max(1, Math.ceil(post.content.split(' ').length / 200))} dk</p>
                        </div>
                    </div>

                    <button
                        className={`like-btn ${isLiked ? 'liked' : ''}`}
                        onClick={handleLike}
                        title={user ? "" : "Giriş yapın"}
                    >
                        <Heart size={24} fill={isLiked ? "currentColor" : "none"} />
                        <span className="like-count">{post.likes?.length || 0}</span>
                    </button>
                </div>
            </div>

            {post.image && (
                <div className="post-hero-image">
                    <img src={`${import.meta.env.VITE_BACKEND_URL || 'http://localhost:5000'}${post.image}`} alt={post.title} />
                </div>
            )}

            <div
                className="post-body ql-editor"
                dangerouslySetInnerHTML={{ __html: post.content }}
            />

            {post.author.bio && (
                <div className="author-bio surface">
                    <h4>{post.author.username} Hakkında</h4>
                    <p>{post.author.bio}</p>
                </div>
            )}
        </article>
    );
};

export default PostDetail;
