import { useState, useContext } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import './Auth.css';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loadingForm, setLoadingForm] = useState(false);
    const { login } = useContext(AuthContext);
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setLoadingForm(true);
        try {
            await login(email, password);
            navigate('/');
        } catch (err) {
            setError(err.response?.data?.message || 'Giriş yapılamadı. Bilgilerinizi kontrol edin.');
        } finally {
            setLoadingForm(false);
        }
    };

    return (
        <div className="auth-container">
            <div className="auth-card surface">
                <h2 className="auth-title">Hoş Geldiniz</h2>
                <p className="auth-subtitle">Hesabınıza giriş yapın</p>

                {error && <div className="auth-error">{error}</div>}

                <form onSubmit={handleSubmit} className="auth-form">
                    <div className="form-group">
                        <label htmlFor="email">Email</label>
                        <input
                            type="email"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                            placeholder="ornek@email.com"
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="password">Şifre</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                            placeholder="••••••••"
                        />
                    </div>
                    <button type="submit" className="btn-primary auth-submit" disabled={loadingForm}>
                        {loadingForm ? 'Bekleyin...' : 'Giriş Yap'}
                    </button>
                </form>

                <div className="auth-footer">
                    Hesabınız yok mu? <Link to="/register">Kayıt Ol</Link>
                </div>
            </div>
        </div>
    );
};

export default Login;
