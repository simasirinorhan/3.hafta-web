import { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { ThemeContext } from '../context/ThemeContext';
import { Sun, Moon, LogOut, User, Edit, Home } from 'lucide-react';
import './Navbar.css';

const Navbar = () => {
    const { user, logout } = useContext(AuthContext);
    const { theme, toggleTheme } = useContext(ThemeContext);
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    return (
        <header className="navbar-container surface">
            <div className="container navbar">
                <Link to="/" className="brand">
                    <span className="brand-logo">B</span>BEUBlog
                </Link>

                <nav className="nav-links">
                    <Link to="/" className="nav-link"><Home size={18} /> Ana Sayfa</Link>
                    {user && <Link to="/create-post" className="nav-link"><Edit size={18} /> Yazı Yaz</Link>}
                </nav>

                <div className="nav-actions">
                    <button onClick={toggleTheme} className="icon-btn" aria-label="Temayı Değiştir">
                        {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
                    </button>

                    {user ? (
                        <div className="user-menu">
                            <Link to="/dashboard" className="nav-link profile-link">
                                <User size={18} /> {user.username}
                            </Link>
                            <button onClick={handleLogout} className="icon-btn logout-btn" aria-label="Çıkış Yap">
                                <LogOut size={20} />
                            </button>
                        </div>
                    ) : (
                        <div className="auth-links">
                            <Link to="/login" className="btn-outline">Giriş</Link>
                            <Link to="/register" className="btn-primary">Kayıt Ol</Link>
                        </div>
                    )}
                </div>
            </div>
        </header>
    );
};

export default Navbar;
