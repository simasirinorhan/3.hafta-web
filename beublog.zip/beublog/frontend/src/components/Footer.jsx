import './Footer.css';

const Footer = () => {
    return (
        <footer className="footer surface">
            <div className="container">
                <div className="footer-content">
                    <div className="footer-brand">
                        <span className="brand-logo-small">B</span>
                        <span className="brand-text">BEUBlog</span>
                    </div>
                    <p className="footer-copyright">&copy; {new Date().getFullYear()} BEUBlog. Tüm hakları saklıdır.</p>
                    <div className="footer-links">
                        <a href="#">Hakkımızda</a>
                        <a href="#">İletişim</a>
                        <a href="#">Gizlilik Politikası</a>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
