import { createContext, useState, useEffect } from 'react';
import api from '../api';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchUser = async () => {
            const storedUser = localStorage.getItem('user');
            if (storedUser) {
                try {
                    // Optional: Verify token by hitting /api/auth/me instead of blindly trusting localStorage
                    const parsed = JSON.parse(storedUser);
                    api.defaults.headers.common['Authorization'] = `Bearer ${parsed.token}`;
                    const res = await api.get('/auth/me');
                    // Update user state with fresh data from DB
                    setUser({ ...res.data, token: parsed.token });
                } catch (error) {
                    console.error("Token verification failed", error);
                    localStorage.removeItem('user');
                }
            }
            setLoading(false);
        };
        fetchUser();
    }, []);

    const login = async (email, password) => {
        const res = await api.post('/auth/login', { email, password });
        setUser(res.data);
        localStorage.setItem('user', JSON.stringify(res.data));
    };

    const register = async (username, email, password) => {
        const res = await api.post('/auth/register', { username, email, password });
        setUser(res.data);
        localStorage.setItem('user', JSON.stringify(res.data));
    };

    const logout = () => {
        setUser(null);
        localStorage.removeItem('user');
        delete api.defaults.headers.common['Authorization'];
    };

    return (
        <AuthContext.Provider value={{ user, login, register, logout, loading, setUser }}>
            {children}
        </AuthContext.Provider>
    );
};
